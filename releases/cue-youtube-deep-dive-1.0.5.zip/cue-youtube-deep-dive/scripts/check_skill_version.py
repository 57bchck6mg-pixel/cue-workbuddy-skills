# -*- coding: utf-8 -*-
"""Check whether this skill has a newer release in the public update manifest.

Prints one line of JSON and always exits 0. Any failure is reported as
{"ok": false} so the caller can stay silent and carry on with the task.
"""

import json
import os
import re
import sys
import time
import urllib.request
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
CACHE_TTL = 24 * 3600
TIMEOUT = 3
MAX_MANIFEST_BYTES = 512 * 1024

DEFAULT_URLS = [
    "https://cdn.jsdelivr.net/gh/57bchck6mg-pixel/cue-workbuddy-skills@main/versions.json",
    "https://raw.githubusercontent.com/57bchck6mg-pixel/cue-workbuddy-skills/main/versions.json",
]
ZIP_HOSTS = {
    "raw.githubusercontent.com",
    "cdn.jsdelivr.net",
    "github.com",
    "objects.githubusercontent.com",
}


def parse_version(value):
    parts = []
    for chunk in str(value).strip().lstrip("vV").split("."):
        match = re.match(r"\d+", chunk)
        parts.append(int(match.group()) if match else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:4])


def cache_dir():
    override = os.environ.get("CUE_SKILL_UPDATE_CACHE")
    path = Path(override) if override else Path.home() / ".cache" / "cue-workbuddy-skills"
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_local_version():
    data = json.loads((SKILL_DIR / "version.json").read_text(encoding="utf-8"))
    return data["slug"], data["version"]


def load_cache():
    path = cache_dir() / "versions.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) and isinstance(data.get("manifest"), dict) else None
    except Exception:
        return None


def save_cache(manifest):
    path = cache_dir() / "versions.json"
    tmp = path.with_suffix(".tmp")
    tmp.write_text(
        json.dumps({"fetched_at": int(time.time()), "manifest": manifest}, ensure_ascii=False),
        encoding="utf-8",
    )
    tmp.replace(path)


def fetch(url):
    if url.startswith("file://"):
        raw = Path(url[7:]).read_bytes()
    else:
        request = urllib.request.Request(url, headers={"User-Agent": "cue-skill-version-check/1"})
        with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
            raw = response.read(MAX_MANIFEST_BYTES + 1)
    if len(raw) > MAX_MANIFEST_BYTES:
        raise ValueError("manifest too large")
    manifest = json.loads(raw.decode("utf-8"))
    if not isinstance(manifest, dict):
        raise ValueError("manifest must be an object")
    return manifest


def get_manifest():
    cached = load_cache()
    if cached and time.time() - int(cached.get("fetched_at", 0)) < CACHE_TTL:
        return cached["manifest"], None, False

    urls = [os.environ["CUE_SKILL_UPDATE_URL"]] if os.environ.get("CUE_SKILL_UPDATE_URL") else DEFAULT_URLS
    last_error = "no manifest source reachable"
    for url in urls:
        try:
            manifest = fetch(url)
            save_cache(manifest)
            return manifest, url, False
        except Exception as exc:
            last_error = f"{type(exc).__name__}: {exc}"

    if cached:
        return cached["manifest"], None, True
    raise RuntimeError(last_error)


def resolve_zip_url(manifest_url, zip_path):
    if not zip_path:
        return None
    if re.match(r"^https://", zip_path):
        return zip_path
    if not manifest_url or not manifest_url.startswith("https://"):
        return None
    return manifest_url.rsplit("/", 1)[0] + "/" + zip_path.lstrip("./")


def check():
    slug, current = read_local_version()
    manifest, manifest_url, stale = get_manifest()

    skills = manifest.get("skills") if isinstance(manifest.get("skills"), dict) else manifest
    entry = skills.get(slug)
    if not entry:
        return {"ok": False, "reason": "slug not in manifest", "slug": slug, "current": current}

    if isinstance(entry, str):
        entry = {"version": entry}
    latest = str(entry.get("version", ""))
    if not latest:
        return {"ok": False, "reason": "manifest entry has no version", "slug": slug, "current": current}

    zip_url = resolve_zip_url(manifest_url, entry.get("zip"))
    result = {
        "ok": True,
        "slug": slug,
        "current": current,
        "latest": latest,
        "outdated": parse_version(latest) > parse_version(current),
        "zip_url": zip_url,
        "sha256": entry.get("sha256"),
        "notes": entry.get("notes"),
        "stale_cache": stale,
        "checked_at": int(time.time()),
    }
    return result


def main():
    try:
        result = check()
    except Exception as exc:
        result = {"ok": False, "reason": f"{type(exc).__name__}: {exc}"}
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
