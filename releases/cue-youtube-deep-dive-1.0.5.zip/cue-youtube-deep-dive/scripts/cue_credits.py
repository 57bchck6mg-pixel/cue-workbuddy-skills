#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Query Cue account available credits.

Usage: python3 scripts/cue_credits.py

Key lookup order: CUE_API_KEY -> $CUE_HOME/config.json -> ~/.cue/config.json
Output: one JSON line on stdout. Exit 0 on success, 1 on failure.
"""
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

DEFAULT_BASE = "https://cuecue.cn/api"
BILLING_PATH = "/v1/billing/subscriptions/current"


def _config_paths():
    home = os.environ.get("CUE_HOME", "").strip()
    paths = []
    if home:
        paths.append(Path(home) / "config.json")
    paths.append(Path.home() / ".cue" / "config.json")
    return paths


def load_config():
    key = os.environ.get("CUE_API_KEY", "").strip()
    base = os.environ.get("CUE_API_BASE", "").strip()
    if not key or not base:
        for path in _config_paths():
            if not path.exists():
                continue
            try:
                blob = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            key = key or str(blob.get("api_key", "")).strip()
            base = base or str(blob.get("base", "")).strip()
            if key and base:
                break
    return key, (base or DEFAULT_BASE).rstrip("/")


def fetch():
    key, base = load_config()
    if not key:
        return {"ok": False, "error": "missing_api_key"}

    req = urllib.request.Request(base + BILLING_PATH, method="GET")
    req.add_header("Authorization", "Bearer " + key)
    req.add_header("Accept", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": "http_%s" % e.code}
    except Exception as e:
        return {"ok": False, "error": type(e).__name__}

    if data is None:
        return {"ok": True, "subscription": False, "available_credits": 0.0}

    def num(name):
        value = data.get(name)
        return float(value) if isinstance(value, (int, float)) else 0.0

    available = data.get("available_credits")
    if not isinstance(available, (int, float)):
        available = num("credits_remaining") + num("daily_remaining")

    return {
        "ok": True,
        "subscription": True,
        "tier": data.get("tier"),
        "status": data.get("status"),
        "available_credits": float(available),
        "credits_remaining": num("credits_remaining"),
        "daily_remaining": num("daily_remaining"),
        "permanent_credits_balance": num("permanent_credits_balance"),
        "next_reset_date": data.get("next_reset_date"),
    }


if __name__ == "__main__":
    result = fetch()
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result.get("ok") else 1)
