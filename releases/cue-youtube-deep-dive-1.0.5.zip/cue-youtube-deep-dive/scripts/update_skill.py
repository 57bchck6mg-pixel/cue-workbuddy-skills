# -*- coding: utf-8 -*-
"""Download the latest skill package and install it when safe to do so.

Market-managed installs (with _meta.json / _skillhub_meta.json) are never
overwritten in place: the zip is saved and the user is told to import it from
WorkBuddy. Self-managed installs are backed up, then replaced.

Prints one line of JSON and always exits 0.
"""

import hashlib
import json
import os
import shutil
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_skill_version as checker  # noqa: E402

SKILL_DIR = checker.SKILL_DIR
MAX_ZIP_BYTES = 80 * 1024 * 1024
MANAGED_MARKERS = ("_meta.json", "_skillhub_meta.json", "_knot_meta.json")


def fail(reason, **extra):
    return {"updated": False, "ok": False, "reason": reason, **extra}


def sha256_of(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def download(url, target):
    host = urllib.parse.urlparse(url).hostname or ""
    if urllib.parse.urlparse(url).scheme != "https" or host not in checker.ZIP_HOSTS:
        raise ValueError(f"refusing download from {host or 'unknown host'}")

    tmp = target.with_suffix(".part")
    request = urllib.request.Request(url, headers={"User-Agent": "cue-skill-updater/1"})
    written = 0
    with urllib.request.urlopen(request, timeout=60) as response, open(tmp, "wb") as handle:
        while True:
            block = response.read(256 * 1024)
            if not block:
                break
            written += len(block)
            if written > MAX_ZIP_BYTES:
                raise ValueError("package exceeds size limit")
            handle.write(block)
    tmp.replace(target)


def candidate_urls(url):
    """Return the original URL plus its raw/jsDelivr counterpart."""
    parsed = urllib.parse.urlparse(url)
    if parsed.hostname == "raw.githubusercontent.com":
        parts = parsed.path.strip("/").split("/", 3)
        if len(parts) == 4:
            owner, repo, branch, rest = parts
            return [url, f"https://cdn.jsdelivr.net/gh/{owner}/{repo}@{branch}/{rest}"]
    if parsed.hostname == "cdn.jsdelivr.net" and parsed.path.startswith("/gh/"):
        parts = parsed.path[len("/gh/"):].split("/", 2)
        if len(parts) == 3 and "@" in parts[1]:
            owner = parts[0]
            repo, branch = parts[1].split("@", 1)
            return [url, f"https://raw.githubusercontent.com/{owner}/{repo}/{branch}/{parts[2]}"]
    return [url]


def validate_zip(path, slug):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if f"{slug}/SKILL.md" not in names:
            raise ValueError("package does not contain SKILL.md")
        for name in names:
            if name.startswith("/") or ".." in Path(name).parts:
                raise ValueError("package contains an unsafe path")


def install_from_zip(path, slug):
    managed = next((m for m in MANAGED_MARKERS if (SKILL_DIR / m).exists()), None)
    if managed:
        return {
            "updated": False,
            "ok": True,
            "mode": "import",
            "downloaded": str(path),
            "message": "该技能由 WorkBuddy 管理，不原地覆盖。请到 WorkBuddy 技能中心 → 导入本地技能，选择刚下载的 zip。",
        }

    backup_root = checker.cache_dir() / "backup"
    backup_root.mkdir(parents=True, exist_ok=True)
    backup = backup_root / f"{slug}-{time.strftime('%Y%m%d-%H%M%S')}"
    shutil.copytree(SKILL_DIR, backup)

    with tempfile.TemporaryDirectory() as tmp:
        with zipfile.ZipFile(path) as archive:
            archive.extractall(tmp)
        source = Path(tmp) / slug
        for item in source.rglob("*"):
            if item.is_file():
                dest = SKILL_DIR / item.relative_to(source)
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, dest)

    return {
        "updated": True,
        "ok": True,
        "mode": "replace",
        "downloaded": str(path),
        "backup": str(backup),
        "message": "已替换本地技能文件，新版本在下次调用时生效。",
    }


def main():
    try:
        status = checker.check()
    except Exception as exc:
        print(json.dumps(fail(f"{type(exc).__name__}: {exc}"), ensure_ascii=False))
        return 0

    if not status.get("ok"):
        print(json.dumps(fail(status.get("reason", "version check failed"), status=status), ensure_ascii=False))
        return 0
    if not status.get("outdated"):
        print(json.dumps({"updated": False, "ok": True, "reason": "already latest", "current": status["current"]}, ensure_ascii=False))
        return 0
    if not status.get("zip_url"):
        print(json.dumps(fail("manifest has no package url", latest=status["latest"]), ensure_ascii=False))
        return 0

    slug = status["slug"]
    download_dir = Path(os.environ.get("CUE_SKILL_UPDATE_DIR") or (Path.home() / "Downloads"))
    download_dir.mkdir(parents=True, exist_ok=True)
    target = download_dir / f"{slug}-{status['latest']}.zip"

    try:
        if target.exists() and status.get("sha256") and sha256_of(target) == status["sha256"]:
            pass
        else:
            errors = []
            for url in candidate_urls(status["zip_url"]):
                try:
                    download(url, target)
                    if status.get("sha256") and sha256_of(target) != status["sha256"]:
                        target.unlink(missing_ok=True)
                        raise ValueError("sha256 mismatch")
                    break
                except Exception as exc:
                    errors.append(f"{type(exc).__name__}: {exc}")
            else:
                raise ValueError("; ".join(errors))
        validate_zip(target, slug)
        result = install_from_zip(target, slug)
    except Exception as exc:
        print(json.dumps(fail(f"{type(exc).__name__}: {exc}", latest=status["latest"]), ensure_ascii=False))
        return 0

    result.update({"ok": True, "latest": status["latest"], "current": status["current"]})
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
