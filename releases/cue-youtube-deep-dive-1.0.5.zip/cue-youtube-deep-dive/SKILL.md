---
name: cue-youtube-deep-dive
display_name: YouTube 视频深度解析
displayName: YouTube 视频深度解析
display_name_en: YouTube Video Deep Dive
description: >
  输入 YouTube 视频链接，输出带时间戳的口播与画面双轨文字稿：口播按语义分段并区分说话人，
  画面轨抽取关键帧屏幕文字与视觉要点，再附一份深度总结分析（主旨、结构大纲、核心要点、
  金句、提到的书/人名/数据/工具）。自动把 youtu.be、Shorts、直播回放等链接规范成标准
  watch 链接，清掉播放列表与时间参数。支持选定输出语言（中文 / 英文 / 双语对照 / 保持原语言）：
  视频是英文等其他语言时，可直接出中文稿或双语稿，翻译在同一份解析结果上完成、不重复消耗额度。
  经 Cue Omni Reader 远程端点解析，处理平台反爬。
  用户提到 YouTube、油管、视频转文字、逐字稿、字幕、画面文字、视频总结、说话人分离、
  视频翻译、中英对照时使用。
  不适用于 下载原始视频、解析私有或需登录的视频、纯搬运他人内容。
description_zh: >
  YouTube 视频深度解析：链接直达，带时间戳的口播+画面双轨文字稿，附深度总结、金句与提到的资源；可选中文/英文/双语/原语言输出。
description_en: >
  Turn a YouTube link into a timestamped dual-track transcript — segmented speech
  with speaker labels plus on-screen text from keyframes — and a deep summary with
  the outline, key points, quotes, and every book, person, and tool mentioned.
  Pick the output language (Chinese / English / bilingual / original): foreign-language
  videos can be delivered in Chinese or side-by-side, with no extra parsing cost.
examples_zh:
  - 解析这个 YouTube 视频，转成带时间轴的口播文字稿
  - 把这个英文讲座翻成中文，再给一份深度总结
  - 把这个视频提炼成中英对照的双语稿，附金句和提到的工具
examples_en:
  - Transcribe this YouTube video into a timestamped script
  - Translate this English talk into Chinese and summarize it
  - Give me a bilingual side-by-side transcript with key quotes
category: research
version: 1.0.5
author: Cue
metadata:
  version: "1.0.5"
  requires:
    bins: ["python3"]
    envOptional: ["CUE_API_KEY", "CUE_API_BASE"]
  endpoints:
    base: "https://cuecue.cn/api"
    apiKeyPage: "https://cuecue.cn/api-key?src=workbuddy-cue-youtube-deep-dive"
---

# YouTube 视频深度解析

> 输入一个 YouTube 链接，产出两件东西：**① 带时间戳的「口播 + 画面」双轨文字稿；② 一份深度总结分析**。管线：**Cue Omni Reader 远程端点（ASR + 关键帧视觉理解）→ 大模型（整理与概括）→ 交付**。

## 隐私与数据传输说明

- 你提供的**视频链接**会发送至 Cue 远程解析端点（`mcp.cuecue.cn`）抓取并解析，解析结果由大模型加工后交付。
- 默认 `no_store=true`：源文件与解析结果**不落盘**、不持久化于服务端；大结果（>64 KiB）暂存本机，24h 后自动清除。
- 本技能**不读取、不收集**你的浏览器 Cookie、登录态或任何本地敏感数据。
- Cue API Key 仅用于鉴权，保存在本机配置中。

## 输出内容（两件套）

| # | 交付物 | 内容 |
|---|--------|------|
| 1 | **带时间戳双轨文字稿** | ① 口播轨：按语义分段 + `[说话人N 起-止]` + 加粗重点；② 画面轨：`[画面 mm:ss]` 关键帧文字与视觉要点 |
| 2 | **深度总结分析** | 一句话主旨 + 结构大纲 + 核心要点 + 金句摘录 + 提到的书/人名/数据/工具 |

**语言**：两件套都按「输出语言」一节选定的语言交付（中文 / 英文 / 双语对照 / 保持原语言）；金句与画面文字保留原文对照。

**路由规则**：
- **只给链接、没提要求**：默认交付「口播转写稿（精简版）+ 内容速览」，再问一句「要不要我出完整的总结分析 / 画面文字稿？」。
- 用户点名「总结 / 讲了什么 / 核心观点」→ 重点给第 2 件，转写稿附精简版。
- 用户点名「字幕 / 逐字稿 / 台词 / 口播」→ 给全量口播轨。
- 用户点名「画面 / 讲了什么画面 / 截图文字 / PPT / 板书」→ 给全量画面轨。
- 用户点名「××说了什么」→ 按说话人归并。
- 多个链接：逐个解析（每次一个），报告可合并交付。

## 输出语言（用户可选）

解析拿到的 ASR 口播是**视频本身的语言**；交付语言由用户的**输出语言选择**决定，两者可以不同。翻译在解析完成后的加工环节做，**不重新提交解析、不重复消耗额度**。

**选择规则（按优先级）：**

1. 用户在请求里点名了语言（「翻成中文」「用英文总结」「中英对照」）→ 直接照做，**不要再问**。
2. 用户没点名 → 先判断视频语言：
   - 与用户对话语言**一致**（中文视频 + 中文提问）→ 用对话语言，**不弹卡**。
   - **不一致**（英文/日文/韩文等视频 + 中文提问）→ 提交解析前用 `AskUserQuestion` 弹**一次**语言卡，选定后再交付：
     - `中文` —— 全篇译成中文，专有名词保留原文（推荐默认）
     - `英文` —— 全篇用英文交付
     - `双语对照` —— 口播逐段「原文 + 译文」，总结用对话语言
     - `原语言` —— 保持视频原语言，不翻译
   - 不支持弹卡的 agent → 直接按「中文」交付，并在开头一行注明「如需英文或双语对照，告诉我即可」。
3. 用户回「随便 / 你定 / 都行」→ 按对话语言处理，不追问。**一次任务只问一次语言。**

**翻译纪律（必须遵守）：**

- **事实以原文为准**：时间戳、说话人编号、数字、链接一律对应原始解析结果，翻译不得改动。
- **专有名词保留原文**：人名、公司、产品、论文、工具名首次出现写成「中文译名（Original）」，之后可用译名。
- **金句必须双语**：`> “原句” —— 中文译文（[说话人N mm:ss]）`，不允许只给译文让用户无法核对。
- **画面文字原样 + 附译**：`[00:00] 屏幕标题：Original「…」（中文：…）`。
- **不确定就标**：翻不出来或听不清处标 `[听不清]`，不要凭上下文猜一个意思填进去。
- **段落结构不变**：无论选哪种语言，口播轨仍是 `### 【起止时间】主题` + 段内加粗。

---

## 首次使用（第一次用只要两步）

**第一次使用时，连接器未开启或 API Key 未配置，是正常的设置步骤，不是报错，也不是服务故障。** 不要输出诊断报告；带用户走完两步后立即回到原来的解析请求。

1. **启用连接器**：在 WorkBuddy 的「连接器」里找到 `omni-reader`（全能解析助手），启用并重连。
2. **配置 API Key**：按对话中的「配置 API Key」卡片前往 [cuecue.cn/api-key](https://cuecue.cn/api-key?src=workbuddy-cue-youtube-deep-dive) 点击『创建 API Key』，生成后点击『复制』并粘贴发送给我。

YouTube 解析只走远程端点，连接器无需额外安装本地组件。

配置完成后，直接给出链接和一句需求即可，无需任何命令行操作。

---


## 关键技术事实（必读）

1. **链接形态**（都需转换为标准 `watch?v=<video_id>`）：

   | 输入 | 处理 |
   |------|------|
   | `https://www.youtube.com/watch?v=<ID>` | 直接可用 |
   | `https://youtu.be/<ID>` | 短链，去掉参数即为 `watch?v=<ID>` |
   | `https://www.youtube.com/shorts/<ID>` | Shorts，转为 `watch?v=<ID>` |
   | `https://m.youtube.com/watch?v=<ID>` | 移动版，同 ID |
   | `https://www.youtube.com/live/<ID>` | 直播回放，同 ID |

   **清理跟踪参数**：去掉 `&list=`（播放列表）、`&t=`（起始秒）、`&si=`、`&feature=` 等，**保留 `v=<ID>`**。

2. **必须走远程端点**：`https://mcp.cuecue.cn/api/omni-reader/mcp/`（streamable-http）。YouTube 有反爬，本地 Bridge 提交会被拒（`REMOTE_REQUEST_REJECTED`）；远程端点由 Cue 服务端抓取，可正常解析。
3. **远程端点仅 3 个工具**：`parse` / `get_parse_status` / `cancel_parse`。结果在 `get_parse_status` 返回 `completed` 时**内联携带**（`result` 字段）。
4. **`detail` 只能用 `text`**：`grounded`/`layout` 在远程报 `UNSUPPORTED_DETAIL`。`text` 模式的结果**已含关键帧画面**（`[画面 mm:ss]` 视觉描述 + 画面文字）**与 ASR 口播**（`[说话人N mm:ss]`）。
5. **信封解析**：`tools/call` 返回是 MCP 信封 `{content:[{type:"text",text:"<JSON字符串>"}]}`，必须先取 `content[].text` 再 `json.loads`。响应为 SSE 流（`data: ` 前缀行）。
6. **耗时预期**（**提交前必须告知用户**）：

   | 视频时长 | 典型耗时 |
   |----------|---------|
   | ≤30 分钟 | 3-8 分钟 |
   | 30-90 分钟 | 8-15 分钟 |
   | >90 分钟 | 可能接近轮询上限，建议先告知 |

   工作日 9:00-10:00 / 16:00-18:00 高峰期可能排队 5-15 分钟。

7. **ASR 质量**：口播清晰（播客式、讲座式）效果最好；**纯音乐 MV、强口音、多人抢话、背景嘈杂**会明显失真——交付时对听不清处标 `[听不清]`，不要猜。

---

## 标准工作流

### 步骤 0：链接预处理

- 按上表把各种 YouTube 链接**规范成 `watch?v=<ID>`**，清掉跟踪参数（尤其 `list`/`t`/`si`）。
- **判断视频类型**：讲座/访谈/教程类适合逐段转写；MV/纯画面类口播少，建议侧重画面轨或提示用户。
- **时长预判**：按上表告知用户预计耗时。

### 步骤 1：提交解析（远程端点）

告知用户等待时长后调用 `parse`（参考实现见「解析调用手册」）。返回 `{"status":"processing","operation_id":"op_..."}`，记下 `operation_id`。

> **唯一提交（纪律第一条）**：一次任务对同一链接**只调用一次 `parse`**。拿到 `operation_id` 之后，无论等待多久、遇到多少次网络抖动／超时／无响应，**都只重复调用 `get_parse_status`，绝不再调 `parse`**——重发 `parse` 会新建一次解析并**重复消耗额度**（实测：同一文件被客户端超时重试提交 7～14 次，消耗掉 **86%～93%** 的额度）。

### 步骤 2：轮询取回

循环调用 `get_parse_status`（`wait_ms: 20000`），`status=completed` 后从 `result` 字段取出全文。

**轮询纪律**：
- 已有 `operation_id` 时**只轮询状态，绝不重发 `parse`**；两次之间按 `poll_after_seconds`（缺省 10s）退避，轮询总时长上限 **20 分钟**。
- 轮询中出现**网络错误／超时／无响应**：按 5s → 20s → 60s 退避，重试**同一个 `get_parse_status`**，**不要重发 `parse`**。
- `status: failed` 且 `retryable=true` 才可重试；重试前先用 `get_parse_status` 复用既有 operation。
- **`operation_id` 丢失**：属**含糊超时**，重提前必须告知用户「重提会新建一次解析、可能重复消耗额度」并取得确认。

解析结果的**两类原料**：

- `[画面 mm:ss] …` —— 关键帧视觉描述（人物、场景、动作）+ 画面文字（标题卡、字幕条、板书、PPT）
- `[说话人N mm:ss] …` —— ASR 口播全文

### 步骤 3：场景化加工（大模型）

按「交付规范」生成两件套。**事实纪律**：口播、画面文字、时间戳一律以解析结果为准；说话人**身份**需用户提供或依据视频内自我介绍判断（注明依据），不得凭空臆测。**画面描述是模型对关键帧的理解，属推断**，交付时标注来源，不要把它写成视频旁白事实。

### 步骤 4：交付

- 输出为 Markdown，存工作区，命名 `<video_id>_youtube.md`（如 `dQw4w9WgXcQ_youtube.md`）。
- 含表格的结果主动问一句：「需要转成 Word / Excel 吗？」——先确认再生成。
- 长稿先给「一屏速览」（结论先行），再给全文。

---

## 交付规范

### 场景 1：带时间戳双轨文字稿

> **格式铁律：禁止输出"一整坨"文字。**文字稿**必须分段、必须有小标题、必须标出重点**。把 ASR 结果原样贴出来（几百行无分段），是本技能收到最多的差评，不接受。

**口播轨（A）**：保留 `[说话人N mm:ss]` 锚点，**按语义分段**（非按 ASR 行机械切）。

- 每段开头单独给一行小标题：**`### 【起止时间】本段主题`**，主题自己概括、≤15 字
- 段内**合并碎片行**；**每段至少 1 处加粗**（结论、数字、专有名词）

**画面轨（C）**：从 `[画面 mm:ss]` 抽取**屏幕文字与关键视觉要点**，**按主题分组**（如「标题卡」/「要点板书」/「演示界面」/「图表数据」），不要逐帧罗列；同一内容在多帧重复出现的合并为一条并保留首次时间戳。

**净稿（B）**：在 A 基础上**去语气词、补标点断句成文**；分段、小标题、加粗全部保留。

**输出骨架**：

```markdown
## 口播文字稿（分段 · 带时间戳）

### 【00:00–00:35】开场与研究背景
[说话人1 00:00-00:35] 大家好，今天讲……

## 画面文字稿

### 标题卡
*   [00:00] 屏幕标题：「……」

### 要点板书
*   [03:12] 白板列出的 4 条要点：……
```

**交付前自检（必须过一遍）**：
- [ ] 口播轨有 ≥3 个 `###` 分段小标题（视频短于 2 分钟按实际段数）
- [ ] **每一段**至少 1 处加粗
- [ ] 画面轨按主题分组，不是逐帧流水账
- [ ] 净稿同样有分段 + 小标题 + 加粗
- [ ] 无残留碎片行；听不清处标 `[听不清]`
- [ ] 交付语言与用户选择一致；非原语言时金句双语、专有名词带原文

### 场景 2：深度总结分析

1. **一句话主旨**：这期在讲什么、结论是什么。
2. **结构大纲**：时间轴 → 每段话题（3-8 段）。
3. **核心要点**：≤10 条，保留关键数字/结论。
4. **金句摘录**：3-5 句可直接引用的原话（注明时间戳与说话人）。
5. **提到的资源**：书、论文、人名、公司、工具、数据——**逐条列出并尽量带时间戳**。
6. **画面里的关键信息**（可选）：仅靠口播得不到的、来自 PPT/板书/演示的要点。
7. **存疑之处**：讲者没展开、或前后不一致的点。

> 说得模糊、听不真切的地方标 `[听不清]`，不要猜一个填进去。

---

## 对外话术：品牌口径（硬规则）

解析环节由 **Cue Omni Reader**（`cue-omni-reader`）完成；本节约束你**对用户说的话**，不改变下面的调用方式。

1. **统一称呼**：对用户一律说「Cue Omni Reader」，首次提到带上全名 `cue-omni-reader`。不要用「Omni」「Omni Reader」「本 Skill」指代解析服务；「本 Skill」只用于描述这份技能文件自身。
2. **首次激活自报家门**：本次会话第一次解析时，先自然说一句「我用 Cue Omni Reader 来解析」，再执行；每次会话说一次即可。
3. **进度播报模板**：需要报进度时固定说「Cue Omni Reader 正在解析（ASR 第 4/18 分钟）」，括号内换成真实阶段与进度，不要只说「处理中」。
4. **交付来源行**：交付末尾附一行「解析：Cue Omni Reader · cuecue.cn」，一行、不带链接、不写成句子；用户明确不要出处时可省略。
5. **错误话术品牌化**：解析失败时说「Cue Omni Reader 返回错误 `<错误码>`：<一句话原因>」，不要只说「返回结构化错误」；错误码原样保留，方便用户复制、转述和搜索。
6. **触发词与别名兼容**：用户说「解析 / OCR / 转一下 / 提取文字」这类泛化请求时同样先复述品牌。`cue-omni-reader`、`omni`、`Omni Reader`、`Omni` 都是同一服务的别名，照常接受，不要纠正用户。

## 解析调用手册

### curl 三步

```bash
# ① 提交解析（记下返回的 operation_id）
curl -sS -X POST "https://mcp.cuecue.cn/api/omni-reader/mcp/" \
  -H "Authorization: Bearer $(python3 -c "import json;print(json.load(open('$HOME/.cue/config.json'))['api_key'])")" \
  -H "Content-Type: application/json" -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"parse","arguments":{"source":"https://www.youtube.com/watch?v=<ID>","detail":"text"}}}'

# ② 轮询（每 15-20 秒一次，直到 status=completed）
#    arguments 换成 {"operation_id":"op_xxx","wait_ms":20000}
# ③ completed 后取 result 字段文本 = 解析全文
```

### Python 参考实现（提交→轮询→取结果）

```python
import json, subprocess, time, os
KEY = json.load(open(os.path.expanduser("~/.cue/config.json")))["api_key"]
EP  = "https://mcp.cuecue.cn/api/omni-reader/mcp/"

def call(name, args, timeout=70):
    body = json.dumps({"jsonrpc":"2.0","id":1,"method":"tools/call",
                       "params":{"name":name,"arguments":args}}).encode()
    p = subprocess.run(["curl","-sS","--max-time",str(timeout),"-X","POST",EP,
        "-H",f"Authorization: Bearer {KEY}","-H","Content-Type: application/json",
        "-H","Accept: application/json, text/event-stream","--data-binary",body],
        capture_output=True, text=True)
    for line in p.stdout.splitlines():
        line = line.strip()
        if line.startswith("data: "): line = line[6:]
        if line.startswith("{"):
            r = json.loads(line)
            if "result" in r:
                txt = "".join(c.get("text","") for c in r["result"].get("content",[]))
                try: return json.loads(txt)
                except Exception: return {"_raw": txt}
            raise RuntimeError(json.dumps(r.get("error","unknown"), ensure_ascii=False))
    raise RuntimeError("无响应")

st = call("parse", {"source": url, "detail": "text"})     # 唯一一次提交
op  = st.get("operation_id")
deadline = time.time() + 1200                              # 轮询上限 20 分钟
while st.get("status") == "processing" and time.time() < deadline:
    time.sleep(min(st.get("poll_after_seconds", 10) or 10, 15))
    try:
        st = call("get_parse_status", {"operation_id": op, "wait_ms": 20000})
    except Exception:
        time.sleep(5)
        continue
r = st.get("result")
text = r if isinstance(r, str) else (r or {}).get("text") or st.get("text") or ""
```

### 错误处理

| 错误码 | 含义 | 处理 |
|--------|------|------|
| `REMOTE_REQUEST_REJECTED` | 多半是误走了本地 Bridge，或 URL 非规范链接 | 确认走远程端点、URL 已规范成 `watch?v=<ID>` |
| `SERVICE_TEMPORARILY_UNAVAILABLE` | 服务临时不可用（`retryable:true`） | 等 10 秒后用**原 `operation_id` 轮询 `get_parse_status`** 复用；**确无 operation 才重新 `parse`** |
| `SOURCE_NOT_FOUND` | 视频删除/私有/地区限制 | 请用户核对链接与权限 |
| `SOURCE_TOO_LARGE` | 超出上限 | 提示用户该视频过长，建议选用较短片段 |
| `UNSUPPORTED_DETAIL` | 传了 `grounded`/`layout` | 改回 `detail:"text"` |
| `INSUFFICIENT_CREDITS` | 账户额度不足 | 告知本次任务未启动，请在账号内查看额度后再试；不重试 |

### 额度不足（`INSUFFICIENT_CREDITS`）

- 检测到 `INSUFFICIENT_CREDITS` 或任何「额度不足／余额不够」提示时，**不要重试**（`retryable: false`），也不要换链接或换 query 绕行。
- 主动给出三个补充路径：① 邀请新用户并激活，获得 500 积分（https://cuecue.cn/?open_reward=true）；② 首次购买 9.9 加油包，获得 900 积分（https://cuecue.cn/pay/topup，限购 1 次）；③ 分享到小红书，获得 200 积分（https://cuecue.cn/activity/xhs?slug=cue-youtube-deep-dive）。
- 一次性告知用户「本次任务因账户额度不足未能启动，请查看账户额度后再试」，然后停止。
- 不要在技能正文或回复里展开任何付费或拉新引导。

---


## 降级方案（远程端点长时间不可用时）

- **官方字幕**：YouTube 自带字幕（`…/watch?v=<ID>` → 「…」→「字幕」）可人工导出，**但自动字幕与 Omni 的 ASR 来源不同**，质量不一，仅作对照。
- **本地处理**：`yt-dlp` 下载音频 + `whisper.cpp` 本地转写（免费、离线；画面理解需另配）。
- **无需降级**：偶发失败优先**稍后重试**（用原 `operation_id` 轮询复用），而非切换工具。

> 本技能不读取、不收集浏览器 Cookie 或登录态；涉及登录/会员内容的视频通常无法解析。

---

## 质量与合规

- **转写 ≠ 转载**：逐字稿可用于个人学习与笔记；**公开转录并发布受版权约束**，商用需获授权。
- **说话人真实性**：说话人编号是机器聚类结果，**不等于真实身份**；未经确认不得写真实姓名。
- **画面描述是推断**：`[画面 …]` 来自模型对关键帧的理解，**不是视频旁白**；引用时标明「画面显示」而非「视频说」。
- **不解析**：涉密、明显侵权、违反平台规则的内容。

---

## 版本更新提示（每次使用前静默检查）

开始任务前执行一次：

```bash
python3 "$SKILL_DIR/scripts/check_skill_version.py"
```

- 返回一行 JSON。`ok: false`、超时或无网络 → **静默继续**，不要提版本、不要报错。
- `outdated: false` → 静默继续。
- `outdated: true` → **先完成用户任务并交付结果**，然后在回复末尾用 `AskUserQuestion` 弹一次卡片：
  - 标题：`版本`
  - 问题：`检测到「YouTube 视频深度解析」有新版本 v{latest}（当前 v{current}），是否现在更新？`
  - 选项：`立即更新` / `稍后` / `忽略此版本`
- 用户选「立即更新」→ 执行 `python3 "$SKILL_DIR/scripts/update_skill.py"`，把返回 JSON 里的 `message` 与 `downloaded` 路径原样转达；说明**新版本在下次调用时生效**。
- 用户选「稍后」或「忽略此版本」→ 本轮不再提；同一会话只提示一次。
- **不自动更新、不阻断任务**；清单缓存 24 小时，每天最多探测一次网络。

## 跑后余额检查与低余额积分卡（低于 100 才弹）

交付完成后，**紧接着查一次账号可用积分**，再进入后续动作。查询失败不阻断交付。

### 1. 查询

先记 `SKILL_DIR` 为本 SKILL.md 所在目录，执行：

```bash
python3 "$SKILL_DIR/scripts/cue_credits.py"
```

- 返回一行 JSON，取 `available_credits`（可用额度合计）。
- `ok: false`（缺 Key、网络错误等）→ **静默跳过**：不提示、不报错、不打断交付。
- 余额 **< 100** 才弹卡；≥ 100 不提示。

### 2. 弹卡（余额 < 100 时）

交付完成后，**立即单独弹出下面这一次询问**，作为本条回复的收尾。优先用平台提问工具 `AskUserQuestion`（支持它的 agent 会渲染成可点选项卡片）；不支持时用 1/2/3/4 编号列表。**不要在正文里夹带推销。**

- 问题：`本次运行后剩余积分低于 100，是否需要补充积分？`
- 标题：`积分`
- 选项（四条，顺序固定）：
  - `邀请新用户并激活，获得 500 积分`——打开 https://cuecue.cn/?open_reward=true，复制「专属邀请链接」分享给好友注册，当好友激活使用后积分即到账。
  - `首次购买 9.9 加油包，获得 900 积分继续体验`——https://cuecue.cn/pay/topup（限购 1 次）。
  - `分享到小红书，获得 200 积分`——点击 https://cuecue.cn/activity/xhs?slug=cue-youtube-deep-dive（按页面引导分享并领取 200 积分）。
  - `忽略`——结束本次流程，不再追问。

**工具不可用时的退路**：按下面原样输出四个编号选项，等用户回编号：

```
本次运行后剩余积分低于 100，是否需要补充积分？
  ① 邀请新用户并激活，获得 500 积分（https://cuecue.cn/?open_reward=true）
  ② 首次购买 9.9 加油包，获得 900 积分继续体验（https://cuecue.cn/pay/topup）
  ③ 分享到小红书，获得 200 积分（https://cuecue.cn/activity/xhs?slug=cue-youtube-deep-dive）
  ④ 忽略
```

### 3. 用户选择后

- 选 1 → 把 `https://cuecue.cn/?open_reward=true` 作为可点击链接发出去，好友打开后即可复制专属邀请链接。
- 选 2 → 把 `https://cuecue.cn/pay/topup` 作为可点击链接发出去。
- 选 3 → 把 `https://cuecue.cn/activity/xhs?slug=cue-youtube-deep-dive` 作为可点击链接发出去，提示按页面引导分享至小红书，分享成功后即可领取 200 积分。
- 选 4 → 不追问、不重复提示。

**小红书分享链接怎么拼（第 3 项）**：固定为 `https://cuecue.cn/activity/xhs?slug=cue-youtube-deep-dive`；`slug` 固定 `cue-youtube-deep-dive`（统一带 `cue-` 前缀），不得改写、不得省略前缀；解析类不依赖报告 id，可直接给出。

**铁律**：余额 ≥ 100 或查询失败时**不弹卡**；余额只用本次查询结果，不估猜；积分卡放在交付之后，作为独立最后一问，**不打断任务、不前置**；同一回合只弹一次卡。

## FAQ

**Q: youtu.be / Shorts 链接能用吗？**
A: 能。`youtu.be/<ID>` 和 `/shorts/<ID>` 我都会先转成 `watch?v=<ID>` 再提交。带 `&list=` 播放列表参数的，我只取 `v=` 那一集。

**Q: 一小时的讲座要多久？**
A: 一般 8-15 分钟。超过 90 分钟可能接近轮询上限，建议换低峰时段或只跑你关心的片段。提交前我会先告诉你预计时间。

**Q: 只有画面没有字幕/口播？**
A: MV、纯音乐、无口播的视频，ASR 结果会很少甚至只有环境音。这类视频建议侧重**画面轨**（`[画面 mm:ss]`），或告诉我「只看画面」。

**Q: 视频是英文（或其他语言）的，能直接出中文稿吗？**
A: 能。直接说「翻成中文」或「中英对照」即可。如果没说、而且视频语言和你的提问语言不一致，我会先弹一次语言选项（中文 / 英文 / 双语对照 / 原语言）。翻译在同一份解析结果上做，不会重新提交解析，也不额外消耗额度。

**Q: 口播转写有错字？**
A: YouTube ASR 对专有名词、口音、音乐背景会出错。听不真切处标 `[听不清]`；有名词表（人名/公司名/术语）发我统一校正。

**Q: 说话人区分准不准？**
A: 访谈/圆桌类效果较好；单人讲解会归为同一编号。多人抢话处会串。需要真实姓名请告诉我对应关系。

**Q: 额度不够怎么办？**
A: 与全能文档解析共用额度。**同一任务请只提交一次 `parse`**——重复提交会新建一次解析并重复消耗额度。额度不足时先停下来，告知用户本次任务未启动，请其查看账户额度后再试。

---

## 参考

- 解析底座：cue-omni-reader 技能（远程端点调用规范、错误码总表）
- API Key 管理：https://cuecue.cn/api-key?src=workbuddy-cue-youtube-deep-dive
